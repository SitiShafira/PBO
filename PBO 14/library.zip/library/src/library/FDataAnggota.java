/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package library;

import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

/**
 *
 * @author Fira
 */
public class FDataAnggota extends javax.swing.JFrame {

    /**
     * Creates new form FDataAnggota
     */
    public FDataAnggota() 
    {
        initComponents();
        load_data(); //memanggil menampilkan data
        IDOtomatis(); //menampilkan id otomatis
        LoadSemester();
        LoadProdi();
        LoadKelas();
        
        BEdit.setEnabled(false);
        BDelete.setEnabled(false);
        
    }
    
    //load data dari database tbl_anggota
    private void load_data() 
    {
        Connection kon = koneksi.koneksiDb();
        Object header[] = {"ID ANGGOTA", "NIM", "NAMA ANGGOTA", "JK", "SEMESTER", "JURUSAN", "KELAS", "NO HP", "STATUS"};
        DefaultTableModel data = new DefaultTableModel(null,header);
        TabelAnggota.setModel(data);
        String sql_data = "SELECT * FROM tbl_anggota";
        try {
            Statement st =kon.createStatement();
            ResultSet rs = st.executeQuery(sql_data);
            while (rs.next()) 
            {
                String d1 = rs.getString(1);
                String d2 = rs.getString(2);
                String d3 = rs.getString(3);
                String d4 = rs.getString(4);
                String d5 = rs.getString(5);
                String d6 = rs.getString(6);
                String d7 = rs.getString(7);
                String d8 = rs.getString(8);
                String d9 = rs.getString(9);
                
                String d[] = {d1, d2, d3, d4, d5, d6, d7, d8, d9};
                data.addRow(d);
            }
        } 
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    //ID Anggota Otomatis
    private void IDOtomatis()
    {
        try 
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_id = "SELECT * FROM tbl_anggota order by id_anggota desc";
            ResultSet rs = st.executeQuery(sql_id);
            if(rs.next())
            {
                String id_anggota = rs.getString("id_anggota").substring(1);
                String AN = "" +(Integer.parseInt(id_anggota) + 1);
                String Nol = "";
                if(AN.length()==1)//jika id_anggota A00001
                {
                    Nol="0000";
                }
                else if(AN.length()==2)//jika id_anggota A00010
                {
                    Nol="000";
                }
                else if(AN.length()==3)//jika id_anggota A00100
                {
                    Nol="00";
                }
                ID.setText("A"+Nol+AN);
            }
            else
            {
                ID.setText("A00001");
            }
        }
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(null, e);
            
        }
    }
    
    public void LoadProdi()
    {
        try 
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_prodi = "SELECT kd_prodi FROM tbl_prodi";
            ResultSet rs = st.executeQuery(sql_prodi);
            while(rs.next()){
                KPRODI.addItem(rs.getString("kd_prodi"));
            }
            rs.close();
        } 
        catch(Exception e) {
            
        }
    }
    
    public void NamaProdi()
    {
        try{
            Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            String sql_prodi="SELECT prodi FROM tbl_prodi WHERE kd_prodi='"+KPRODI.getSelectedItem()+"'";
            ResultSet rs=st.executeQuery(sql_prodi);
            while(rs.next()){
                NPRODI.setText(rs.getString("prodi"));
            }
        }
        catch(Exception e){
            
        }
    }
    public void LoadSemester()
    {
        try 
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_semester = "SELECT * FROM tbl_semester";
            ResultSet rs = st.executeQuery(sql_semester);
            while(rs.next()){
                KSEMESTER.addItem(rs.getString("id_semester"));
            }
            rs.close();
        } 
        catch(Exception e) {
            
        }
    }
    
    public void NamaSemester()
    {
        try{
            Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            String sql_semester="SELECT semester FROM tbl_semester WHERE id_semester='"+KSEMESTER.getSelectedItem()+"'";
            ResultSet rs=st.executeQuery(sql_semester);
            while(rs.next()){
                NSEMESTER.setText(rs.getString("semester"));
            }
        }
        catch(Exception e){
            
        }
    }
   
    public void LoadKelas()
    {
        try 
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_kelas = "SELECT id_kelas FROM tbl_kelas";
            ResultSet rs = st.executeQuery(sql_kelas);
            while(rs.next()){
                KKELAS.addItem(rs.getString("id_kelas"));
            }
            rs.close();
        } 
        catch(Exception e) {
            
        }
    }
    
    //input data
    private void input_data()
    {
        try
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            
            //untuk jenis kelamin
            String jk="";
            if(JKP.isSelected())
            {
                jk=JKP.getText();
            }
            else
            {
                jk=JKW.getText();
            }
            
            String sql="INSERT INTO tbl_anggota values('"+ID.getText()
                    +"','"+NIM.getText()
                    +"','"+NAMA.getText()
                    +"','"+jk
                    +"','"+KSEMESTER.getSelectedItem()
                    +"','"+KPRODI.getSelectedItem()
                    +"','"+KKELAS.getSelectedItem()
                    +"','"+NOPE.getText()
                    +"','"+STATUS.getSelectedItem()
                    +"')";
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Anggota Berhasil ditambahkan");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    //Reset Data setelah input/edit/delete
    public void clear(){
        NIM.setText("");
        NAMA.setText("");
        NOPE.setText("");
        JKP.setSelected(rootPaneCheckingEnabled);
        KSEMESTER.setSelectedItem(1);
        KPRODI.setSelectedItem("RPLA");
        KKELAS.setSelectedItem(1);
        STATUS.setSelectedItem("AKTIF");
    }
    
    //Edit data
    private void update()
    {
        try
        {
            Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            String jk="";
            if(JKP.isSelected())
            {
                jk=JKP.getText();
            }
            else
            {
                jk=JKW.getText();
            }
            
            String sql_update = "UPDATE tbl_anggota SET nim='"+NIM.getText()
                    +"',nama_anggota='"+NAMA.getText()
                    +"',jk='"+jk
                    +"',id_semester='"+ KSEMESTER.getSelectedItem()
                    +"',kd_prodi='"+KPRODI.getSelectedItem()
                    +"',id_kelas='"+KKELAS.getSelectedItem()
                    +"',nope='"+NOPE.getText()
                    +"',status='"+STATUS.getSelectedItem()
                    +"'WHERE id_anggota='"+ID.getText()+"'";
            st.execute(sql_update);
            JOptionPane.showMessageDialog(null, "Data Berhasil di Update");
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    //Delete Data
    private void delete()
    {
        try
        {
            Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            String sql_delete="DELETE FROM tbl_anggota WHERE "
                    + "id_anggota='"+ID.getText()+"'";
            st.executeUpdate(sql_delete);
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
            
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void tampil(){
       
       DefaultTableModel model = new DefaultTableModel();
       
       model.addColumn("ID ANGGOTA");
       model.addColumn("NIM");
       model.addColumn("NAMA ANGGOTA");
       model.addColumn("JK");
       model.addColumn("SEMESTER");
       model.addColumn("JURUSAN");
       model.addColumn("KELAS");
       model.addColumn("NO HP");
       model.addColumn("STATUS");
       
       String cari = txtCari.getText();
       try {
           int no = 1;
           String sql_cari = "SELECT * FROM tbl_anggota WHERE nama_anggota LIKE'%"+cari+"%'";
           Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            ResultSet rs = st.executeQuery(sql_cari);
            
            while (rs.next()){
                model.addRow(new Object[]{no++, rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)});
                TabelAnggota.setModel(model);
            }
       }
       catch(Exception e){
           
       }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JK = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        BKeluar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        ID = new javax.swing.JTextField();
        NIM = new javax.swing.JTextField();
        NAMA = new javax.swing.JTextField();
        KSEMESTER = new javax.swing.JComboBox<>();
        KPRODI = new javax.swing.JComboBox<>();
        KKELAS = new javax.swing.JComboBox<>();
        NOPE = new javax.swing.JTextField();
        STATUS = new javax.swing.JComboBox<>();
        NPRODI = new javax.swing.JTextField();
        BInput = new javax.swing.JButton();
        BEdit = new javax.swing.JButton();
        BDelete = new javax.swing.JButton();
        JKP = new javax.swing.JRadioButton();
        JKW = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelAnggota = new javax.swing.JTable();
        NSEMESTER = new javax.swing.JTextField();
        RESET = new javax.swing.JButton();
        txtCari = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setForeground(new java.awt.Color(0, 153, 153));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("KELOLA DATA ANGGOTA PERPUSTAKAAN");

        BKeluar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        BKeluar.setText("Keluar");
        BKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BKeluarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID ANGGOTA :");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NIM :");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("NAMA ANGGOTA :");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("JENIS KELAMIN :");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("SEMESTER :");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("JURUSAN :");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("KELAS :");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("NO HP :");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("STATUS :");

        ID.setEnabled(false);

        NAMA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NAMAActionPerformed(evt);
            }
        });

        KSEMESTER.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KSEMESTERMouseClicked(evt);
            }
        });
        KSEMESTER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KSEMESTERActionPerformed(evt);
            }
        });

        KPRODI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KPRODIActionPerformed(evt);
            }
        });

        STATUS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AKTIF", "TIDAK AKTIF" }));
        STATUS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                STATUSActionPerformed(evt);
            }
        });

        NPRODI.setEditable(false);
        NPRODI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NPRODIActionPerformed(evt);
            }
        });

        BInput.setText("INPUT");
        BInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BInputActionPerformed(evt);
            }
        });

        BEdit.setText("EDIT");
        BEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BEditActionPerformed(evt);
            }
        });

        BDelete.setText("DELETE");
        BDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BDeleteActionPerformed(evt);
            }
        });

        JK.add(JKP);
        JKP.setSelected(true);
        JKP.setText("PRIA");
        JKP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JKPActionPerformed(evt);
            }
        });

        JK.add(JKW);
        JKW.setText("WANITA");
        JKW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JKWActionPerformed(evt);
            }
        });

        TabelAnggota.setBackground(new java.awt.Color(153, 153, 153));
        TabelAnggota.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelAnggota.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelAnggotaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelAnggota);

        NSEMESTER.setEditable(false);
        NSEMESTER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NSEMESTERActionPerformed(evt);
            }
        });

        RESET.setText("RESET");
        RESET.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RESETActionPerformed(evt);
            }
        });

        txtCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCariKeyReleased(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("CARI :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(JKP)
                                        .addGap(56, 56, 56)
                                        .addComponent(JKW)
                                        .addGap(144, 144, 144))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(NIM, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel4)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(NAMA, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(24, 24, 24)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(KPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(KSEMESTER, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(NSEMESTER, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE))
                                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                        .addGap(108, 108, 108)
                                                        .addComponent(NPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(NOPE, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(KKELAS, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(BKeluar)
                                        .addGap(59, 59, 59)
                                        .addComponent(BInput)
                                        .addGap(18, 18, 18)
                                        .addComponent(BEdit)
                                        .addGap(18, 18, 18)
                                        .addComponent(BDelete)
                                        .addGap(18, 18, 18)
                                        .addComponent(RESET))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(23, 23, 23)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(STATUS, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1017, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(NIM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(NAMA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(JKP)
                            .addComponent(JKW))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(KSEMESTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NSEMESTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(KPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NPRODI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(KKELAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(NOPE, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(STATUS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BKeluar)
                    .addComponent(BInput)
                    .addComponent(BEdit)
                    .addComponent(BDelete)
                    .addComponent(RESET))
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BKeluarActionPerformed
        // TODO add your handling code here:
        int keluar = JOptionPane.showOptionDialog(this, 
                "Keluar dari Kelola Data Anggota?", 
                "Exit", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, null, null);
        if(keluar == JOptionPane.YES_NO_OPTION)
        {
            new FUtamaPustakawan().show();
            this.dispose();
        }
    }//GEN-LAST:event_BKeluarActionPerformed

    private void JKPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JKPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JKPActionPerformed

    private void NAMAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NAMAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NAMAActionPerformed

    private void NPRODIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NPRODIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NPRODIActionPerformed

    private void BInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BInputActionPerformed
        // TODO add your handling code here:
        //confirm data
        int simpan = JOptionPane.showOptionDialog(this, 
                "Apakah Data Sudah Benar?",
                "SIMPAN DATA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,null,null);
        
        if(simpan==JOptionPane.YES_OPTION){
            input_data();
            load_data();
            clear();
            IDOtomatis();
        }
        
    }//GEN-LAST:event_BInputActionPerformed

    private void KSEMESTERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KSEMESTERActionPerformed
        // TODO add your handling code here:
        NamaSemester();
    }//GEN-LAST:event_KSEMESTERActionPerformed

    private void KSEMESTERMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KSEMESTERMouseClicked
        // TODO add your handling code here:
        
     
    }//GEN-LAST:event_KSEMESTERMouseClicked

    private void KPRODIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KPRODIActionPerformed
        // TODO add your handling code here:
        NamaProdi();
    }//GEN-LAST:event_KPRODIActionPerformed

    private void JKWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JKWActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JKWActionPerformed

    private void NSEMESTERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NSEMESTERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NSEMESTERActionPerformed

    private void TabelAnggotaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelAnggotaMouseClicked
        // TODO add your handling code here:
        int bar = TabelAnggota.getSelectedRow();
        String a = TabelAnggota.getValueAt(bar, 0).toString();
        String b = TabelAnggota.getValueAt(bar, 1).toString();
        String c = TabelAnggota.getValueAt(bar, 2).toString();
        String d = TabelAnggota.getValueAt(bar, 3).toString();
        String e = TabelAnggota.getValueAt(bar, 4).toString();
        String f = TabelAnggota.getValueAt(bar, 5).toString();
        String g = TabelAnggota.getValueAt(bar, 6).toString();
        String h = TabelAnggota.getValueAt(bar, 7).toString();
        String i = TabelAnggota.getValueAt(bar, 8).toString();
        
        ID.setText(a);
        NIM.setText(b);
        NAMA.setText(c);
        //Jenis Kelamin
        if("PRIA".equals(d)){
            JKP.setSelected(true);
        }
        else
        {
            JKW.setSelected(true);
        }
        //Semester
        KSEMESTER.setSelectedItem(e);
        KPRODI.setSelectedItem(f);
        KKELAS.setSelectedItem(g);
        NOPE.setText(h);
        //Status
        if("AKTIF".equals(i)){
            STATUS.setSelectedItem(i);
        }
        else{
            STATUS.setSelectedItem(i);
        }
        
        //Set Disable INPUT
        BInput.setEnabled(false);
        BEdit.setEnabled(true);
        BDelete.setEnabled(true);
        
    }//GEN-LAST:event_TabelAnggotaMouseClicked

    private void BEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BEditActionPerformed
        // TODO add your handling code here:
        int update = JOptionPane.showOptionDialog(this, 
                "Apakah Data Akan di Update?",
                "UPDATE DATA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,null,null);
        
        if(update==JOptionPane.YES_OPTION){
            update();
        clear();
        load_data();
        IDOtomatis();
        
        //Set Enable INPUT
        BInput.setEnabled(true);
        BEdit.setEnabled(false);
        BDelete.setEnabled(false);
        }
        
    }//GEN-LAST:event_BEditActionPerformed

    private void BDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BDeleteActionPerformed
        // TODO add your handling code here:
        int delete = JOptionPane.showOptionDialog(this, 
                "Apakah Yakin Akan Menghapus Data?",
                "DELETE DATA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,null,null);
        
        if(delete==JOptionPane.YES_OPTION)
        {
            delete();
            clear();
            load_data();
            IDOtomatis();
        
        //Set Enable delete
        BInput.setEnabled(true);
        BEdit.setEnabled(false);
        BDelete.setEnabled(false);
        }
    }//GEN-LAST:event_BDeleteActionPerformed

    private void STATUSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_STATUSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_STATUSActionPerformed

    private void RESETActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RESETActionPerformed
        // TODO add your handling code here:
        clear();
        load_data();
        IDOtomatis();
        
        BInput.setEnabled(true);
        BEdit.setEnabled(false);
        BDelete.setEnabled(false);
    }//GEN-LAST:event_RESETActionPerformed

    private void txtCariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCariKeyReleased
        // TODO add your handling code here:
        tampil();
    }//GEN-LAST:event_txtCariKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FDataAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FDataAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FDataAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FDataAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FDataAnggota().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BDelete;
    private javax.swing.JButton BEdit;
    private javax.swing.JButton BInput;
    private javax.swing.JButton BKeluar;
    private javax.swing.JTextField ID;
    private javax.swing.ButtonGroup JK;
    private javax.swing.JRadioButton JKP;
    private javax.swing.JRadioButton JKW;
    private javax.swing.JComboBox<String> KKELAS;
    private javax.swing.JComboBox<String> KPRODI;
    private javax.swing.JComboBox<String> KSEMESTER;
    private javax.swing.JTextField NAMA;
    private javax.swing.JTextField NIM;
    private javax.swing.JTextField NOPE;
    private javax.swing.JTextField NPRODI;
    private javax.swing.JTextField NSEMESTER;
    private javax.swing.JButton RESET;
    private javax.swing.JComboBox<String> STATUS;
    private javax.swing.JTable TabelAnggota;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCari;
    // End of variables declaration//GEN-END:variables
}
