/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package library;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Fira
 */
public class FDataPeminjaman extends javax.swing.JFrame {
    

    /**
     * Creates new form FDataPeminjaman
     */
    public FDataPeminjaman() {
        initComponents();
        load_data();
        IDOtomatis();
        LoadJudul();
        LoadProdi();
    }
    
    private void load_data() 
    {
        Connection kon = koneksi.koneksiDb();
        Object header[] = {"ID", "NIM", "NAMA ANGGOTA", "JUDUL", "PRODI", "NO HP", "TGL PEMINJAMAN", "TGL PENGEMBALIAN"};
        DefaultTableModel data = new DefaultTableModel(null,header);
        TabelPeminjaman.setModel(data);
        String sql_data = "SELECT * FROM tbl_peminjaman";
        try {
            Statement st =kon.createStatement();
            ResultSet rs = st.executeQuery(sql_data);
            while (rs.next()) 
            {
                String d1 = rs.getString(1);
                String d2 = rs.getString(2);
                String d3 = rs.getString(3);
                String d4 = rs.getString(4);
                String d5 = rs.getString(5);
                String d6 = rs.getString(6);
                String d7 = rs.getString(7);
                String d8 = rs.getString(8);
                
                
                String d[] = {d1, d2, d3, d4, d5, d6, d7, d8};
                data.addRow(d);
            }
        } 
        catch(Exception e) 
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    //ID otomatis untuk nomor
    private void IDOtomatis(){
        try{
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_id = "SELECT * FROM tbl_peminjaman order by id_peminjaman desc";
            ResultSet rs = st.executeQuery(sql_id);
            if(rs.next())
            {
                String id_peminjaman = rs.getString("id_peminjaman").substring(1);
                String AN = "" +(Integer.parseInt(id_peminjaman) + 1);
                String Nol = "";
                if(AN.length()==1)//jika id_peminjaman P00001
                {
                    Nol="0000";
                }
                else if(AN.length()==2)//jika id_peminjaman P00010
                {
                    Nol="000";
                }
                else if(AN.length()==3)//jika id_peminjaman P00100
                {
                    Nol="00";
                }
                IDPeminjaman.setText("P"+Nol+AN);
            }
            else
            {
                IDPeminjaman.setText("P00001");
            }
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void LoadJudul()
    {
        try 
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_judul = "SELECT judul FROM tbl_databuku";
            ResultSet rs = st.executeQuery(sql_judul);
            while(rs.next()){
                JUDUL.addItem(rs.getString("judul"));
            }
            rs.close();
        } 
        catch(Exception e) {
            
        }
    }
    
    public void LoadProdi()
    {
        try 
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql_prodi = "SELECT kd_prodi FROM tbl_prodi";
            ResultSet rs = st.executeQuery(sql_prodi);
            while(rs.next()){
                PRODI.addItem(rs.getString("kd_prodi"));
            }
            rs.close();
        } 
        catch(Exception e) {
            
        }
    }
    
    private void input_data()
    {
        try
        {
            Connection kon =koneksi.koneksiDb();
            Statement st =kon.createStatement();
            String sql="INSERT INTO tbl_peminjaman values('"+IDPeminjaman.getText()
                    +"','"+NIM.getText()
                    +"','"+NAMA.getText()
                    +"','"+JUDUL.getSelectedItem()
                    +"','"+PRODI.getSelectedItem()
                    +"','"+NOPE.getText()
                    +"','"+TGLPINJAM.getText()
                    +"','"+TGLKEMBALI.getText()
                    +"')";
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Peminjaman Buku Berhasil ditambahkan");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void clear(){
        
        NIM.setText("");
        NAMA.setText("");
        JUDUL.setSelectedItem("Dear Nathan");
        PRODI.setSelectedItem("RPLA");
        NOPE.setText("");
        TGLPINJAM.setText("");
        TGLKEMBALI.setText("");
    }
    
    private void update()
    {
        try
        {
            Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            String sql_update = "UPDATE tbl_peminjaman SET nim='"+NIM.getText()
                    +"',nama_anggota='"+NAMA.getText()
                    +"',judul='"+ JUDUL.getSelectedItem()
                    +"',prodi='"+PRODI.getSelectedItem()
                    +"',nope='"+NOPE.getText()
                    +"',tgl_pinjam='"+TGLPINJAM.getText()
                    +"',tgl_kembali='"+TGLKEMBALI.getText()
                    +"'WHERE id_peminjaman='"+IDPeminjaman.getText()+"'";
            st.execute(sql_update);
            JOptionPane.showMessageDialog(null, "Data Berhasil di Update");
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void delete()
    {
        try
        {
            Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            String sql_delete="DELETE FROM tbl_peminjaman WHERE "
                    + "id_peminjaman='"+IDPeminjaman.getText()+"'";
            st.executeUpdate(sql_delete);
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
            
            
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
   public void tampil(){
       
       DefaultTableModel model = new DefaultTableModel();
       
       model.addColumn("ID");
       model.addColumn("NIM");
       model.addColumn("NAMA ANGGOTA");
       model.addColumn("JUDUL");
       model.addColumn("PRODI");
       model.addColumn("NO HP");
       model.addColumn("TGL PEMINJAMAN");
       model.addColumn("TGL PENGEMBALIAN");
       
       String cari = txtCari.getText();
       try {
           int no = 1;
           String sql_cari = "SELECT * FROM tbl_peminjaman WHERE nama_anggota LIKE'%"+cari+"%'";
           Connection kon = koneksi.koneksiDb();
            Statement st = kon.createStatement();
            ResultSet rs = st.executeQuery(sql_cari);
            
            while (rs.next()){
                model.addRow(new Object[]{no++, rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)});
                TabelPeminjaman.setModel(model);
            }
       }
       catch(Exception e){
           
       }
       
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        IDPeminjaman = new javax.swing.JTextField();
        NIM = new javax.swing.JTextField();
        NAMA = new javax.swing.JTextField();
        JUDUL = new javax.swing.JComboBox<>();
        PRODI = new javax.swing.JComboBox<>();
        NOPE = new javax.swing.JTextField();
        TGLPINJAM = new javax.swing.JTextField();
        TGLKEMBALI = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelPeminjaman = new javax.swing.JTable();
        SIMPAN = new javax.swing.JButton();
        EDIT = new javax.swing.JButton();
        DELETE = new javax.swing.JButton();
        KELUAR = new javax.swing.JButton();
        txtCari = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        RESET = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setForeground(new java.awt.Color(0, 102, 102));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("DATA PEMINJAMAN BUKU PERPUSTAKAAN");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID PEMINJAMAN :");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NIM :");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("NAMA ANGGOTA :");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("JUDUL BUKU :");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("PRODI :");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("NO HP :");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("TANGGAL PEMINJAMAN :");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("TANGGAL PENGEMBALIAN :");

        IDPeminjaman.setEnabled(false);

        TGLKEMBALI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TGLKEMBALIActionPerformed(evt);
            }
        });

        TabelPeminjaman.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelPeminjaman.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelPeminjamanMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelPeminjaman);

        SIMPAN.setText("SIMPAN");
        SIMPAN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SIMPANActionPerformed(evt);
            }
        });

        EDIT.setText("EDIT");
        EDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDITActionPerformed(evt);
            }
        });

        DELETE.setText("DELETE");
        DELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DELETEActionPerformed(evt);
            }
        });

        KELUAR.setText("KELUAR");
        KELUAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KELUARActionPerformed(evt);
            }
        });

        txtCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCariKeyReleased(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("CARI :");

        RESET.setText("RESET");
        RESET.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RESETActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(KELUAR)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(IDPeminjaman)
                                            .addComponent(NIM)
                                            .addComponent(TGLPINJAM)
                                            .addComponent(TGLKEMBALI)
                                            .addComponent(NAMA)
                                            .addComponent(JUDUL, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(PRODI, 0, 139, Short.MAX_VALUE)
                                            .addComponent(NOPE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(SIMPAN)
                                        .addGap(18, 18, 18)
                                        .addComponent(EDIT)
                                        .addGap(18, 18, 18)
                                        .addComponent(DELETE)
                                        .addGap(18, 18, 18)
                                        .addComponent(RESET)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1062, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(IDPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(NIM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(NAMA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(JUDUL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(PRODI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(NOPE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TGLPINJAM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TGLKEMBALI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addGap(49, 49, 49)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SIMPAN)
                            .addComponent(EDIT)
                            .addComponent(DELETE)
                            .addComponent(RESET)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(KELUAR)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void TGLKEMBALIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TGLKEMBALIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TGLKEMBALIActionPerformed

    private void KELUARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KELUARActionPerformed
        // TODO add your handling code here:
        int keluar = JOptionPane.showOptionDialog(this, 
                "Keluar dari Data Peminjaman Buku?", 
                "Exit", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, null, null);
        if(keluar == JOptionPane.YES_NO_OPTION)
        {
            new FUtamaPustakawan().show();
            this.dispose();
        }
    }//GEN-LAST:event_KELUARActionPerformed

    private void SIMPANActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SIMPANActionPerformed
        // TODO add your handling code here:
        int simpan = JOptionPane.showOptionDialog(this, 
                "Apakah Data Sudah Benar?",
                "SIMPAN DATA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,null,null);
        
        if(simpan==JOptionPane.YES_OPTION){
            input_data();
            load_data();
            clear();
            IDOtomatis();
        }
    }//GEN-LAST:event_SIMPANActionPerformed

    private void DELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETEActionPerformed
        // TODO add your handling code here:
        int delete = JOptionPane.showOptionDialog(this, 
                "Apakah Yakin Akan Menghapus Data Peminjam?",
                "DELETE DATA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,null,null);
        
        if(delete==JOptionPane.YES_OPTION)
        {
            delete();
            clear();
            load_data();
            IDOtomatis();
        
        //Set Enable delete
        SIMPAN.setEnabled(true);
        EDIT.setEnabled(false);
        DELETE.setEnabled(false);
        }
    }//GEN-LAST:event_DELETEActionPerformed

    private void EDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDITActionPerformed
        // TODO add your handling code here:
        int update = JOptionPane.showOptionDialog(this, 
                "Apakah Data Akan di Update?",
                "UPDATE DATA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,null,null);
        
        if(update==JOptionPane.YES_OPTION){
            update();
            clear();
            load_data();
            IDOtomatis();
        
        //Set Enable INPUT
        SIMPAN.setEnabled(true);
        EDIT.setEnabled(false);
        DELETE.setEnabled(false);
        }
    }//GEN-LAST:event_EDITActionPerformed

    private void TabelPeminjamanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelPeminjamanMouseClicked
        // TODO add your handling code here:
        int bar = TabelPeminjaman.getSelectedRow();
        String a = TabelPeminjaman.getValueAt(bar, 0).toString();
        String b = TabelPeminjaman.getValueAt(bar, 1).toString();
        String c = TabelPeminjaman.getValueAt(bar, 2).toString();
        String d = TabelPeminjaman.getValueAt(bar, 3).toString();
        String e = TabelPeminjaman.getValueAt(bar, 4).toString();
        String f = TabelPeminjaman.getValueAt(bar, 5).toString();
        String g = TabelPeminjaman.getValueAt(bar, 6).toString();
        String h = TabelPeminjaman.getValueAt(bar, 7).toString();
        
        IDPeminjaman.setText(a);
        NIM.setText(b);
        NAMA.setText(c);
        JUDUL.setSelectedItem(d);
        PRODI.setSelectedItem(e);
        NOPE.setText(f);
        TGLPINJAM.setText(g);
        TGLKEMBALI.setText(h);
        
        //Set Disable INPUT
        SIMPAN.setEnabled(false);
        EDIT.setEnabled(true);
        DELETE.setEnabled(true);
    }//GEN-LAST:event_TabelPeminjamanMouseClicked

    private void RESETActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RESETActionPerformed
        // TODO add your handling code here:
        clear();
        load_data();
        IDOtomatis();
        
        SIMPAN.setEnabled(true);
        EDIT.setEnabled(false);
        DELETE.setEnabled(false);
    }//GEN-LAST:event_RESETActionPerformed

    private void txtCariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCariKeyReleased
        // TODO add your handling code here:
        tampil();
    }//GEN-LAST:event_txtCariKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FDataPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FDataPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FDataPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FDataPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FDataPeminjaman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DELETE;
    private javax.swing.JButton EDIT;
    private javax.swing.JTextField IDPeminjaman;
    private javax.swing.JComboBox<String> JUDUL;
    private javax.swing.JButton KELUAR;
    private javax.swing.JTextField NAMA;
    private javax.swing.JTextField NIM;
    private javax.swing.JTextField NOPE;
    private javax.swing.JComboBox<String> PRODI;
    private javax.swing.JButton RESET;
    private javax.swing.JButton SIMPAN;
    private javax.swing.JTextField TGLKEMBALI;
    private javax.swing.JTextField TGLPINJAM;
    private javax.swing.JTable TabelPeminjaman;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCari;
    // End of variables declaration//GEN-END:variables
}
